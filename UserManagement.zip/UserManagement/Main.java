import exceptions.AuthException;
import model.Utilisateur;
import service.AuthService;
import service.UserService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserService userService = new UserService();
        AuthService authService = new AuthService(userService);

        // Création d'un utilisateur admin par défaut
        try {
            userService.ajouterUtilisateur(new Utilisateur("admin", "admin123", "admin"));
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        Utilisateur utilisateurConnecte = null;

        while (true) {
            if (utilisateurConnecte == null) {
                System.out.println("=== Connexion ===");
                System.out.print("Nom d'utilisateur : ");
                String username = scanner.nextLine();
                System.out.print("Mot de passe : ");
                String mdp = scanner.nextLine();

                try {
                    utilisateurConnecte = authService.login(username, mdp);
                    System.out.println("✅ Connecté en tant que : " + utilisateurConnecte.getUsername());
                } catch (AuthException e) {
                    System.out.println("❌ " + e.getMessage());
                }
            } else {
                System.out.println("\n=== Menu Principal ===");
                System.out.println("1. Lister utilisateurs");
                System.out.println("2. Ajouter utilisateur");
                System.out.println("3. Modifier utilisateur");
                System.out.println("4. Supprimer utilisateur");
                System.out.println("5. Déconnexion");
                System.out.print("Choix : ");
                int choix = Integer.parseInt(scanner.nextLine());

                try {
                    switch (choix) {
                        case 1:
                            for (Utilisateur u : userService.listerUtilisateurs()) {
                                System.out.println(u);
                            }
                            break;
                        case 2:
                            if (!utilisateurConnecte.getRole().equals("admin")) {
                                System.out.println("❌ Accès refusé. Seul admin peut ajouter.");
                                break;
                            }
                            System.out.print("Nom d'utilisateur : ");
                            String newUsername = scanner.nextLine();
                            System.out.print("Mot de passe : ");
                            String newMdp = scanner.nextLine();
                            System.out.print("Rôle (admin/user) : ");
                            String newRole = scanner.nextLine();
                            userService.ajouterUtilisateur(new Utilisateur(newUsername, newMdp, newRole));
                            System.out.println("✅ Utilisateur ajouté !");
                            break;
                        case 3:
                            if (!utilisateurConnecte.getRole().equals("admin")) {
                                System.out.println("❌ Accès refusé. Seul admin peut modifier.");
                                break;
                            }
                            System.out.print("Nom d'utilisateur à modifier : ");
                            String modUsername = scanner.nextLine();
                            System.out.print("Nouveau mot de passe (laisser vide pour ne pas changer) : ");
                            String modMdp = scanner.nextLine();
                            System.out.print("Nouveau rôle (laisser vide pour ne pas changer) : ");
                            String modRole = scanner.nextLine();
                            userService.modifierUtilisateur(modUsername, modMdp, modRole);
                            System.out.println("✅ Utilisateur modifié !");
                            break;
                        case 4:
                            if (!utilisateurConnecte.getRole().equals("admin")) {
                                System.out.println("❌ Accès refusé. Seul admin peut supprimer.");
                                break;
                            }
                            System.out.print("Nom d'utilisateur à supprimer : ");
                            String delUsername = scanner.nextLine();
                            userService.supprimerUtilisateur(delUsername);
                            System.out.println("✅ Utilisateur supprimé !");
                            break;
                        case 5:
                            System.out.println("👋 Déconnexion...");
                            utilisateurConnecte = null;
                            break;
                        default:
                            System.out.println("❌ Choix invalide.");
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("❌ Erreur : " + e.getMessage());
                }
            }
        }
    }
}
