package service;

import model.Utilisateur;

import java.util.ArrayList;
import java.util.List;

public class UserService {
    private List<Utilisateur> utilisateurs = new ArrayList<>();

    // Ajouter un utilisateur
    public void ajouterUtilisateur(Utilisateur user) throws IllegalArgumentException {
        if (chercherParUsername(user.getUsername()) != null) {
            throw new IllegalArgumentException("Utilisateur déjà existant avec ce nom d'utilisateur.");
        }
        utilisateurs.add(user);
    }

    // Trouver utilisateur par username
    public Utilisateur chercherParUsername(String username) {
        for (Utilisateur u : utilisateurs) {
            if (u.getUsername().equals(username)) {
                return u;
            }
        }
        return null;
    }

    // Modifier utilisateur (changer mot de passe ou rôle)
    public void modifierUtilisateur(String username, String nouveauMotDePasse, String nouveauRole) throws IllegalArgumentException {
        Utilisateur user = chercherParUsername(username);
        if (user == null) {
            throw new IllegalArgumentException("Utilisateur non trouvé.");
        }
        if (nouveauMotDePasse != null && !nouveauMotDePasse.isEmpty()) {
            user.setMotDePasse(nouveauMotDePasse);
        }
        if (nouveauRole != null && !nouveauRole.isEmpty()) {
            user.setRole(nouveauRole);
        }
    }

    // Supprimer utilisateur
    public void supprimerUtilisateur(String username) throws IllegalArgumentException {
        Utilisateur user = chercherParUsername(username);
        if (user == null) {
            throw new IllegalArgumentException("Utilisateur non trouvé.");
        }
        utilisateurs.remove(user);
    }

    // Lister tous les utilisateurs
    public List<Utilisateur> listerUtilisateurs() {
        return utilisateurs;
    }
}
