package service;

import exceptions.AuthException;
import model.Utilisateur;

public class AuthService {
    private UserService userService;

    public AuthService(UserService userService) {
        this.userService = userService;
    }

    public Utilisateur login(String username, String motDePasse) throws AuthException {
        Utilisateur user = userService.chercherParUsername(username);
        if (user == null) {
            throw new AuthException("Utilisateur inconnu.");
        }
        if (!user.getMotDePasse().equals(motDePasse)) {
            throw new AuthException("Mot de passe incorrect.");
        }
        return user;
    }
}
