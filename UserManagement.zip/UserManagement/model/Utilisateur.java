package model;

public class Utilisateur {
    private String username;
    private String motDePasse;
    private String role; // "admin" ou "user"

    public Utilisateur(String username, String motDePasse, String role) {
        this.username = username;
        this.motDePasse = motDePasse;
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public String getRole() {
        return role;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "Utilisateur{" +
                "username='" + username + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}
